﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            textBox1 = new TextBox();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            button16 = new Button();
            button17 = new Button();
            button18 = new Button();
            button19 = new Button();
            button20 = new Button();
            button21 = new Button();
            button22 = new Button();
            button23 = new Button();
            button24 = new Button();
            button25 = new Button();
            button26 = new Button();
            button27 = new Button();
            button28 = new Button();
            button29 = new Button();
            button30 = new Button();
            button31 = new Button();
            button32 = new Button();
            label1 = new Label();
            label2 = new Label();
            button33 = new Button();
            button34 = new Button();
            button35 = new Button();
            button36 = new Button();
            label3 = new Label();
            button37 = new Button();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            textBox2 = new TextBox();
            label7 = new Label();
            button38 = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(67, 114);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 0;
            button1.Text = "röle 1 on";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(148, 114);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 2;
            button2.Text = "röle 2 on";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(229, 114);
            button3.Name = "button3";
            button3.Size = new Size(75, 23);
            button3.TabIndex = 3;
            button3.Text = "röle 3 on";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(11, 422);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(766, 23);
            textBox1.TabIndex = 4;
            // 
            // button4
            // 
            button4.Location = new Point(310, 114);
            button4.Name = "button4";
            button4.Size = new Size(75, 23);
            button4.TabIndex = 5;
            button4.Text = "röle 4 on";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.Location = new Point(391, 114);
            button5.Name = "button5";
            button5.Size = new Size(75, 23);
            button5.TabIndex = 6;
            button5.Text = "röle 5 on";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.Location = new Point(472, 114);
            button6.Name = "button6";
            button6.Size = new Size(75, 23);
            button6.TabIndex = 7;
            button6.Text = "röle 6 on";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // button7
            // 
            button7.Location = new Point(553, 114);
            button7.Name = "button7";
            button7.Size = new Size(75, 23);
            button7.TabIndex = 8;
            button7.Text = "röle 7 on";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.Location = new Point(634, 114);
            button8.Name = "button8";
            button8.Size = new Size(75, 23);
            button8.TabIndex = 9;
            button8.Text = "röle 8 on";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // button9
            // 
            button9.Location = new Point(67, 211);
            button9.Name = "button9";
            button9.Size = new Size(75, 23);
            button9.TabIndex = 10;
            button9.Text = "röle 9 on";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // button10
            // 
            button10.Location = new Point(148, 211);
            button10.Name = "button10";
            button10.Size = new Size(75, 23);
            button10.TabIndex = 11;
            button10.Text = "röle 10 on";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button10_Click;
            // 
            // button11
            // 
            button11.Location = new Point(229, 211);
            button11.Name = "button11";
            button11.Size = new Size(75, 23);
            button11.TabIndex = 12;
            button11.Text = "röle 11 on";
            button11.UseVisualStyleBackColor = true;
            button11.Click += button11_Click;
            // 
            // button12
            // 
            button12.Location = new Point(310, 211);
            button12.Name = "button12";
            button12.Size = new Size(75, 23);
            button12.TabIndex = 13;
            button12.Text = "röle 12 on";
            button12.UseVisualStyleBackColor = true;
            button12.Click += button12_Click;
            // 
            // button13
            // 
            button13.Location = new Point(391, 211);
            button13.Name = "button13";
            button13.Size = new Size(75, 23);
            button13.TabIndex = 14;
            button13.Text = "röle 13 on";
            button13.UseVisualStyleBackColor = true;
            button13.Click += button13_Click;
            // 
            // button14
            // 
            button14.Location = new Point(472, 211);
            button14.Name = "button14";
            button14.Size = new Size(75, 23);
            button14.TabIndex = 15;
            button14.Text = "röle 14 on";
            button14.UseVisualStyleBackColor = true;
            button14.Click += button14_Click;
            // 
            // button15
            // 
            button15.Location = new Point(553, 211);
            button15.Name = "button15";
            button15.Size = new Size(75, 23);
            button15.TabIndex = 16;
            button15.Text = "röle 15 on";
            button15.UseVisualStyleBackColor = true;
            button15.Click += button15_Click;
            // 
            // button16
            // 
            button16.Location = new Point(634, 211);
            button16.Name = "button16";
            button16.Size = new Size(75, 23);
            button16.TabIndex = 17;
            button16.Text = "röle 16 on";
            button16.UseVisualStyleBackColor = true;
            button16.Click += button16_Click;
            // 
            // button17
            // 
            button17.Location = new Point(67, 153);
            button17.Name = "button17";
            button17.Size = new Size(75, 23);
            button17.TabIndex = 18;
            button17.Text = "röle 1 off";
            button17.UseVisualStyleBackColor = true;
            button17.Click += button17_Click;
            // 
            // button18
            // 
            button18.Location = new Point(148, 153);
            button18.Name = "button18";
            button18.Size = new Size(75, 23);
            button18.TabIndex = 19;
            button18.Text = "röle 2 off";
            button18.UseVisualStyleBackColor = true;
            button18.Click += button18_Click;
            // 
            // button19
            // 
            button19.Location = new Point(229, 153);
            button19.Name = "button19";
            button19.Size = new Size(75, 23);
            button19.TabIndex = 20;
            button19.Text = "röle 3 off";
            button19.UseVisualStyleBackColor = true;
            button19.Click += button19_Click;
            // 
            // button20
            // 
            button20.Location = new Point(310, 153);
            button20.Name = "button20";
            button20.Size = new Size(75, 23);
            button20.TabIndex = 21;
            button20.Text = "röle 4 off";
            button20.UseVisualStyleBackColor = true;
            button20.Click += button20_Click;
            // 
            // button21
            // 
            button21.Location = new Point(391, 153);
            button21.Name = "button21";
            button21.Size = new Size(75, 23);
            button21.TabIndex = 22;
            button21.Text = "röle 5 off";
            button21.UseVisualStyleBackColor = true;
            button21.Click += button21_Click;
            // 
            // button22
            // 
            button22.Location = new Point(472, 153);
            button22.Name = "button22";
            button22.Size = new Size(75, 23);
            button22.TabIndex = 23;
            button22.Text = "röle 6 off";
            button22.UseVisualStyleBackColor = true;
            button22.Click += button22_Click;
            // 
            // button23
            // 
            button23.Location = new Point(553, 153);
            button23.Name = "button23";
            button23.Size = new Size(75, 23);
            button23.TabIndex = 24;
            button23.Text = "röle 7 off";
            button23.UseVisualStyleBackColor = true;
            button23.Click += button23_Click;
            // 
            // button24
            // 
            button24.Location = new Point(634, 153);
            button24.Name = "button24";
            button24.Size = new Size(75, 23);
            button24.TabIndex = 25;
            button24.Text = "röle 8 off";
            button24.UseVisualStyleBackColor = true;
            button24.Click += button24_Click;
            // 
            // button25
            // 
            button25.Location = new Point(67, 240);
            button25.Name = "button25";
            button25.Size = new Size(75, 23);
            button25.TabIndex = 26;
            button25.Text = "röle 9 off";
            button25.UseVisualStyleBackColor = true;
            button25.Click += button25_Click;
            // 
            // button26
            // 
            button26.Location = new Point(148, 240);
            button26.Name = "button26";
            button26.Size = new Size(75, 23);
            button26.TabIndex = 27;
            button26.Text = "röle 10 off";
            button26.UseVisualStyleBackColor = true;
            button26.Click += button26_Click;
            // 
            // button27
            // 
            button27.Location = new Point(229, 240);
            button27.Name = "button27";
            button27.Size = new Size(75, 23);
            button27.TabIndex = 28;
            button27.Text = "röle 11 off";
            button27.UseVisualStyleBackColor = true;
            button27.Click += button27_Click;
            // 
            // button28
            // 
            button28.Location = new Point(310, 240);
            button28.Name = "button28";
            button28.Size = new Size(75, 23);
            button28.TabIndex = 29;
            button28.Text = "röle 12 off";
            button28.UseVisualStyleBackColor = true;
            button28.Click += button28_Click;
            // 
            // button29
            // 
            button29.Location = new Point(391, 240);
            button29.Name = "button29";
            button29.Size = new Size(75, 23);
            button29.TabIndex = 30;
            button29.Text = "röle 13 off";
            button29.UseVisualStyleBackColor = true;
            button29.Click += button29_Click;
            // 
            // button30
            // 
            button30.Location = new Point(472, 240);
            button30.Name = "button30";
            button30.Size = new Size(75, 23);
            button30.TabIndex = 31;
            button30.Text = "röle 14 off";
            button30.UseVisualStyleBackColor = true;
            button30.Click += button30_Click;
            // 
            // button31
            // 
            button31.Location = new Point(553, 240);
            button31.Name = "button31";
            button31.Size = new Size(75, 23);
            button31.TabIndex = 32;
            button31.Text = "röle 15 off";
            button31.UseVisualStyleBackColor = true;
            button31.Click += button31_Click;
            // 
            // button32
            // 
            button32.Location = new Point(634, 240);
            button32.Name = "button32";
            button32.Size = new Size(75, 23);
            button32.TabIndex = 33;
            button32.Text = "röle 16 off";
            button32.UseVisualStyleBackColor = true;
            button32.Click += button32_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(305, 404);
            label1.Name = "label1";
            label1.Size = new Size(181, 15);
            label1.TabIndex = 34;
            label1.Text = " Röle Binary Adc 10 Bit Durumları";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(326, 73);
            label2.Name = "label2";
            label2.Size = new Size(160, 15);
            label2.TabIndex = 35;
            label2.Text = "4-8-16 Röle Kontrol Butonları";
            // 
            // button33
            // 
            button33.Location = new Point(218, 325);
            button33.Name = "button33";
            button33.Size = new Size(75, 23);
            button33.TabIndex = 36;
            button33.Text = "röle 1 on";
            button33.UseVisualStyleBackColor = true;
            button33.Click += button33_Click;
            // 
            // button34
            // 
            button34.Location = new Point(326, 325);
            button34.Name = "button34";
            button34.Size = new Size(75, 23);
            button34.TabIndex = 37;
            button34.Text = "röle 2 on";
            button34.UseVisualStyleBackColor = true;
            button34.Click += button34_Click;
            // 
            // button35
            // 
            button35.Location = new Point(218, 354);
            button35.Name = "button35";
            button35.Size = new Size(75, 23);
            button35.TabIndex = 38;
            button35.Text = "röle 1 off";
            button35.UseVisualStyleBackColor = true;
            button35.Click += button35_Click;
            // 
            // button36
            // 
            button36.Location = new Point(326, 354);
            button36.Name = "button36";
            button36.Size = new Size(75, 23);
            button36.TabIndex = 39;
            button36.Text = "röle 2 off";
            button36.UseVisualStyleBackColor = true;
            button36.Click += button36_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(222, 291);
            label3.Name = "label3";
            label3.Size = new Size(179, 15);
            label3.TabIndex = 40;
            label3.Text = "Ethernet 2 Röle Kontrol Butonları";
            // 
            // button37
            // 
            button37.Location = new Point(443, 325);
            button37.Name = "button37";
            button37.Size = new Size(206, 52);
            button37.TabIndex = 41;
            button37.Text = "Röle Adc Durumları";
            button37.UseVisualStyleBackColor = true;
            button37.Click += button37_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BorderStyle = BorderStyle.FixedSingle;
            label4.Location = new Point(148, 96);
            label4.Name = "label4";
            label4.Size = new Size(292, 17);
            label4.TabIndex = 42;
            label4.Text = "ETH-4- 1                     2                         3                           4";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BorderStyle = BorderStyle.Fixed3D;
            label5.Location = new Point(12, 138);
            label5.Name = "label5";
            label5.Size = new Size(47, 17);
            label5.TabIndex = 43;
            label5.Text = "PORT B";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BorderStyle = BorderStyle.Fixed3D;
            label6.Location = new Point(11, 229);
            label6.Name = "label6";
            label6.Size = new Size(48, 17);
            label6.TabIndex = 44;
            label6.Text = "PORT D";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(433, 32);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(195, 23);
            textBox2.TabIndex = 45;
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(24, 35);
            label7.Name = "label7";
            label7.Size = new Size(403, 15);
            label7.TabIndex = 46;
            label7.Text = "IP NO: default ip http://169.254.1.2:3000 veya http://192.168.1.123:3000 gibi:";
            // 
            // button38
            // 
            button38.Location = new Point(634, 32);
            button38.Name = "button38";
            button38.Size = new Size(75, 23);
            button38.TabIndex = 47;
            button38.Text = "KAYIT";
            button38.UseVisualStyleBackColor = true;
            button38.Click += button38_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(794, 457);
            Controls.Add(button38);
            Controls.Add(label7);
            Controls.Add(textBox2);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(button37);
            Controls.Add(label3);
            Controls.Add(button36);
            Controls.Add(button35);
            Controls.Add(button34);
            Controls.Add(button33);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button32);
            Controls.Add(button31);
            Controls.Add(button30);
            Controls.Add(button29);
            Controls.Add(button28);
            Controls.Add(button27);
            Controls.Add(button26);
            Controls.Add(button25);
            Controls.Add(button24);
            Controls.Add(button23);
            Controls.Add(button22);
            Controls.Add(button21);
            Controls.Add(button20);
            Controls.Add(button19);
            Controls.Add(button18);
            Controls.Add(button17);
            Controls.Add(button16);
            Controls.Add(button15);
            Controls.Add(button14);
            Controls.Add(button13);
            Controls.Add(button12);
            Controls.Add(button11);
            Controls.Add(button10);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(textBox1);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "Form1";
            Text = "http get request sedaelektronik.com";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button2;
        private Button button3;
        private TextBox textBox1;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button button16;
        private Button button17;
        private Button button18;
        private Button button19;
        private Button button20;
        private Button button21;
        private Button button22;
        private Button button23;
        private Button button24;
        private Button button25;
        private Button button26;
        private Button button27;
        private Button button28;
        private Button button29;
        private Button button30;
        private Button button31;
        private Button button32;
        private Label label1;
        private Label label2;
        private Button button33;
        private Button button34;
        private Button button35;
        private Button button36;
        private Label label3;
        private Button button37;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox textBox2;
        private Label label7;
        private Button button38;
    }
}