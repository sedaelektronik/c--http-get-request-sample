using System;
using System.IO;
using System.Net;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        private string url = "http://169.254.1.2:3000"; // Varsay�lan URL

        public Form1()
        {
            InitializeComponent();
            LoadUrlFromFile(); // Program ba�lad���nda URL'yi dosyadan y�kle
        }

        // URL'yi txt dosyas�ndan y�kle
        private void LoadUrlFromFile()
        {
            string filePath = "url.txt";
            if (File.Exists(filePath))
            {
                string savedUrl = File.ReadAllText(filePath);
                if (!string.IsNullOrEmpty(savedUrl))
                {
                    url = savedUrl;
                    textBox2.Text = savedUrl; // TextBox2'ye kay�tl� URL'yi yaz
                }
            }
        }

        // IP Kaydet butonu
        private void button38_Click(object sender, EventArgs e)
        {
            string newUrl = textBox2.Text.Trim();
            if (!string.IsNullOrEmpty(newUrl))
            {
                url = newUrl;
                File.WriteAllText("url.txt", newUrl);
                MessageBox.Show("URL ba�ar�yla kaydedildi!");
            }
            else
            {
                MessageBox.Show("L�tfen ge�erli bir URL girin!");
            }
        }

        // TextBox2 de�i�ti�inde URL'yi g�ncelle
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            url = textBox2.Text.Trim();
        }

        // Buton 1
        private void button1_Click(object sender, EventArgs e)
        {
            SendRequest("/1");
        }

        // Buton 2
        private void button2_Click(object sender, EventArgs e)
        {
            SendRequest("/2");
        }

        // Buton 3
        private void button3_Click(object sender, EventArgs e)
        {
            SendRequest("/3");
        }

        // Buton 4
        private void button4_Click(object sender, EventArgs e)
        {
            SendRequest("/4");
        }

        // Buton 5
        private void button5_Click(object sender, EventArgs e)
        {
            SendRequest("/5");
        }

        // Buton 6
        private void button6_Click(object sender, EventArgs e)
        {
            SendRequest("/6");
        }

        // Buton 7
        private void button7_Click(object sender, EventArgs e)
        {
            SendRequest("/7");
        }

        // Buton 8
        private void button8_Click(object sender, EventArgs e)
        {
            SendRequest("/8");
        }

        // Buton 9
        private void button9_Click(object sender, EventArgs e)
        {
            SendRequest("/9");
        }

        // Buton 10
        private void button10_Click(object sender, EventArgs e)
        {
            SendRequest("/0");
        }

        // Buton 11
        private void button11_Click(object sender, EventArgs e)
        {
            SendRequest("/a");
        }

        // Buton 12
        private void button12_Click(object sender, EventArgs e)
        {
            SendRequest("/b");
        }

        // Buton 13
        private void button13_Click(object sender, EventArgs e)
        {
            SendRequest("/c");
        }

        // Buton 14
        private void button14_Click(object sender, EventArgs e)
        {
            SendRequest("/d");
        }

        // Buton 15
        private void button15_Click(object sender, EventArgs e)
        {
            SendRequest("/e");
        }

        // Buton 16
        private void button16_Click(object sender, EventArgs e)
        {
            SendRequest("/L");
        }

        // Buton 17
        private void button17_Click(object sender, EventArgs e)
        {
            SendRequest("/i");
        }

        // Buton 18
        private void button18_Click(object sender, EventArgs e)
        {
            SendRequest("/g");
        }

        // Buton 19
        private void button19_Click(object sender, EventArgs e)
        {
            SendRequest("/h");
        }

        // Buton 20
        private void button20_Click(object sender, EventArgs e)
        {
            SendRequest("/j");
        }

        // Buton 21
        private void button21_Click(object sender, EventArgs e)
        {
            SendRequest("/k");
        }

        // Buton 22
        private void button22_Click(object sender, EventArgs e)
        {
            SendRequest("/l");
        }

        // Buton 23
        private void button23_Click(object sender, EventArgs e)
        {
            SendRequest("/m");
        }

        // Buton 24
        private void button24_Click(object sender, EventArgs e)
        {
            SendRequest("/n");
        }

        // Buton 25
        private void button25_Click(object sender, EventArgs e)
        {
            SendRequest("/o");
        }

        // Buton 26
        private void button26_Click(object sender, EventArgs e)
        {
            SendRequest("/p");
        }

        // Buton 27
        private void button27_Click(object sender, EventArgs e)
        {
            SendRequest("/q");
        }

        // Buton 28
        private void button28_Click(object sender, EventArgs e)
        {
            SendRequest("/t");
        }

        // Buton 29
        private void button29_Click(object sender, EventArgs e)
        {
            SendRequest("/u");
        }

        // Buton 30
        private void button30_Click(object sender, EventArgs e)
        {
            SendRequest("/v");
        }

        // Buton 31
        private void button31_Click(object sender, EventArgs e)
        {
            SendRequest("/w");
        }

        // Buton 32
        private void button32_Click(object sender, EventArgs e)
        {
            SendRequest("/M");
        }

        // Buton 33
        private void button33_Click(object sender, EventArgs e)
        {
            SendRequest("/w");
        }

        // Buton 34
        private void button34_Click(object sender, EventArgs e)
        {
            SendRequest("/n");
        }

        // Buton 35
        private void button35_Click(object sender, EventArgs e)
        {
            SendRequest("/m");
        }

        // Buton 36
        private void button36_Click(object sender, EventArgs e)
        {
            SendRequest("/t");
        }

        // Buton 37
        private void button37_Click(object sender, EventArgs e)
        {
            SendRequest("/s");
        }

        // Ortak istek g�nderme metodu
        private void SendRequest(string endpoint)
        {
            var requestUrl = $"{url}{endpoint}";
            var request = WebRequest.Create(requestUrl);
            request.Method = "GET";

            using var webResponse = request.GetResponse();
            using var webStream = webResponse.GetResponseStream();
            using var reader = new StreamReader(webStream);
            var data = reader.ReadToEnd();

            textBox1.Text = data; // Sonucu TextBox1'de g�ster
        }
    }
}